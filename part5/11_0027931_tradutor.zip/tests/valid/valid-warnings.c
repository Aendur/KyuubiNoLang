int func(void) {
	char a = 'c';
	char b = '\0';
	char c = '\'';
	char d = '"';
	char s1[] = "str";
	char s2[] = "str\"'\"";
}