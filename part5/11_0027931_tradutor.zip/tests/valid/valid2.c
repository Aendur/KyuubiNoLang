int main(void) {
	int a = -1;
	int b = +1;
	int c = 5;
	int d = -c;
	do {
		b = b * --c;
	} while (!(c == 0));



	int h = 0xFFFFFFFF;
	float x = 1.0;
	float y = -123.456789;
	float z = +3.14159;
	return 0;
}

