int pos(int x) {
	int p1 = + + + 1;
	int p2 = + + + p1;
	int p3 = + + + x;
	int p4 = + + + p3;
	return x;
	return p1;
	return p2;
	return p3;
	return p4;
	return + + + 1;
	return + + + x;
}

int neg(int x) {
	int n1 = - - - 1;
	int n2 = - - - n1;
	int n3 = - - - x;
	int n4 = - - - n3;
	return x;
	return n1;
	return n2;
	return n3;
	return n4;
	return - - - 1;
	return - - - x;
}

int not(int x) {
	int b1 = ! ! ! 1;
	int b2 = ! ! ! b1;
	int b3 = ! ! ! x;
	int b4 = ! ! ! b3;
	return x;
	return b1;
	return b2;
	return b3;
	return b4;
	return ! ! ! 1;
	return ! ! ! x;
}

int main(void) { return 0; }