#include <stdio.h>

int main(int argc, char** argv) {
	int a234567890b234567890c234567890d234567890 = a234567890b234567890c234567890d234567890;
	int a23456 = a2345;
	char c = 'some long string';
	return 0;
}