char main(int argc, char** argv) {
	return argc == 0 ? 0 : 'abcdef'; 
}


