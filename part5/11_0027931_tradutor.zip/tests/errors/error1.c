char main(int argc, char** argv) {
	// syntax and lexical errors
	// ? and : are not recognized
	return argc == 0 ? 0 : 'abcdef'; 
}


