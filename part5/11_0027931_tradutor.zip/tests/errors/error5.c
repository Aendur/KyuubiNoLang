float div(float x) {
	float div = 0.0;
	float a1 = 1 / div;
	float a2 = x / div;
	float a3 = 1 / 0;
	float a4 = x / 0;
}

float mod(float x) {
	float mod = 0.0;
	float a1 = 1 % mod;
	float a2 = x % mod;
	float a3 = 1 % 0;
	float a4 = x % 0;
}

