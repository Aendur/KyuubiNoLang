int gx;

int main(int argc) {
	gx = 5;
	write(gx);
	write();
	char str1[] = "awooo";
	write(str1);
	write();
	return 0;
}

