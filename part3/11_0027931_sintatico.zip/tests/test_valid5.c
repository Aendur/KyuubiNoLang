// polymorphic functions signatures
int min(int x, int y);
int min(int x, int y, int z);
float min(float x, float y);
float min(float x, float y, float z);

void write(char c);
void write(int i);
void write(float f);
void write(char s[]);
void write(int i[]);
void write(float f[]);


