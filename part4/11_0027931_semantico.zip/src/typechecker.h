#ifndef TYPECHECKER_H
#define TYPECHECKER_H

void typecheck(struct node * tree);

#endif

